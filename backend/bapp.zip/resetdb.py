from app.database.database import Base, engine

print("⚠️  Dropping all tables...")
Base.metadata.drop_all(bind=engine)

print("✅ Creating fresh tables...")
Base.metadata.create_all(bind=engine)

print("🎉 Database reset complete.")
